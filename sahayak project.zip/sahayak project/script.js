// Define prompt templates for each mode
const prompts = {
    information: "You are a helpful assistant for elderly users. Answer their general question simply and clearly.",
    religious: "You are a respectful religious companion. Talk about stories and teachings from holy books in a comforting way.",
    wellness: "You are a supportive health guide. Provide simple wellness advice to an elderly user.",
    order: "You help elderly users place online orders. Ask them what they want and where it should be delivered.",
    emergency: "You detect emergency. Ask the user to confirm and suggest calling emergency contacts or helpline.",
    memory: "You help users remember things. Store and recall past inputs."
  };
  
  let selectedMode = "information"; // Default mode
  
  // Add event listeners to mode buttons
  document.querySelectorAll(".mode-btn").forEach(button => {
    button.addEventListener("click", () => {
      selectedMode = button.getAttribute("data-mode");
      alert(Mode changed to: ${selectedMode});
    });
  });
  // Check if browser supports SpeechRecognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SpeechRecognition) {
  alert("Your browser does not support speech recognition. Please try Chrome.");
} else {
  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';

  recognition.onresult = function(event) {
    const voiceText = event.results[0][0].transcript;
    document.getElementById("display-text").innerText = voiceText;
    // Once we get the voice input, call the function to get a response.
    handleUserInput(voiceText);
  };

  recognition.onerror = function(e) {
    console.error(e);
    alert("Error during speech recognition. Please try again.");
  };

  document.getElementById("start-voice").addEventListener("click", () => {
    recognition.start();
  });
}
async function handleUserInput(query) {
    document.getElementById("response-text").innerText = "Processing...";
  
    // Build the payload for the LLM API call
    const payload = {
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: prompts[selectedMode] },
        { role: "user", content: query }
      ]
    };
  
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": "Bearer YOUR_API_KEY_HERE", // Replace with your actual API key
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      const aiText = data.choices[0].message.content;
      document.getElementById("response-text").innerText = aiText;
      speak(aiText); // Convert response to audio
    } catch (error) {
      console.error(error);
      document.getElementById("response-text").innerText = "Error: Unable to get a response.";
    }
  }
  function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    speechSynthesis.speak(utterance);
  }