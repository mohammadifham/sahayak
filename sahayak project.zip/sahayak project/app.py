from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(_name_)
CORS(app)  # Allow calls from frontend

@app.route('/api/ask', methods=['POST'])
def ask():
    data = request.get_json()
    user_input = data.get("input", "")
    mode = data.get("mode", "default")

    # Simulated response for each mode
    responses = {
        "information": f"You asked: '{user_input}'. Here's some general information.",
        "religious": f"Blessings to you. Here's something spiritual: '{user_input}'.",
        "wellness": f"Take care of your health. Tip: {user_input}.",
        "order": f"Processing your request: {user_input}.",
        "emergency": f"Emergency mode activated. Action taken for: {user_input}.",
        "memory": f"Memory saved: {user_input}.",
        "default": f"I'm your companion. You said: {user_input}"
    }

    reply = responses.get(mode.lower(), responses["default"])

    return jsonify({"response": reply})

if _name_ == '_main_':
    app.run(port=5000, debug=True)s